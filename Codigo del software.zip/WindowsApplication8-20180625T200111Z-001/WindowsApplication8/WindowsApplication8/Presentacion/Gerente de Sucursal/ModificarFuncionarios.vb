﻿Public Class ModificarFuncionarios
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteSMenu.Show()
    End Sub

    Private Sub btnBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        If CheckFuncionario(tbCedula.Text) = False Then
            MsgBox("Funcionario Encontrado")
            BuscarFuncionario(tbCedula.Text)
            tbNombre.Enabled = True
            tbApellido.Enabled = True
            tbTelefono1.Enabled = True
            tbTelefono2.Enabled = True
            tbDireccion.Enabled = True
            tbCedula.Enabled = False
            btnModificar.Enabled = True

        Else
            MsgBox("Funcionario No Encontrado")
            tbCedula.Clear()
            tbNombre.Clear()
            tbApellido.Clear()
            tbTelefono1.Clear()
            tbTelefono2.Clear()
            tbDireccion.Clear()
            tbNombre.Enabled = False
            tbApellido.Enabled = False
            tbTelefono1.Enabled = False
            tbTelefono2.Enabled = False
            tbDireccion.Enabled = False
            btnModificar.Enabled = False
        End If
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        ModificacionPersonal(tbCedula.Text, tbNombre.Text, tbApellido.Text, tbDireccion.Text)
        tbCedula.Clear()
        tbNombre.Clear()
        tbApellido.Clear()
        tbTelefono1.Clear()
        tbTelefono2.Clear()
        tbDireccion.Clear()
        tbNombre.Enabled = False
        tbApellido.Enabled = False
        tbTelefono1.Enabled = False
        tbTelefono2.Enabled = False
        tbDireccion.Enabled = False
        btnModificar.Enabled = False
        tbCedula.Enabled = True
    End Sub
End Class