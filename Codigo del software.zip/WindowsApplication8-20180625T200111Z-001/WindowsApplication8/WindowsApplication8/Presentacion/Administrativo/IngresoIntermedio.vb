﻿Public Class IngresoIntermedio
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        AltaProducto(tbId.Text, tbTipo.Text, tbVariedad.Text, tbEstado.Text)
        Transportes(tbId.Text, cmbLugar.Text, dtpIngreso.Text, tbMatricula.Text, tbCantidad.Text, tbCapacidad.Text)
    End Sub

    Private Sub IngresoIntermedio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Combo3()
    End Sub

    Private Sub tbId_MouseMove(sender As Object, e As MouseEventArgs) Handles tbVariedad.MouseMove, tbMatricula.MouseMove, tbId.MouseMove, tbEstado.MouseMove, tbCapacidad.MouseMove, tbCantidad.MouseMove, cmbLugar.MouseMove
        If String.IsNullOrEmpty(tbId.Text) Or
      String.IsNullOrEmpty(tbVariedad.Text) Or
      String.IsNullOrEmpty(tbEstado.Text) Or
      String.IsNullOrEmpty(tbMatricula.Text) Or
      String.IsNullOrEmpty(tbCapacidad.Text) Or
      String.IsNullOrEmpty(cmbLugar.Text) Or
      String.IsNullOrEmpty(tbCantidad.Text) Then
            btnIngresar.Enabled = False
        Else
            btnIngresar.Enabled = True
        End If
    End Sub
End Class