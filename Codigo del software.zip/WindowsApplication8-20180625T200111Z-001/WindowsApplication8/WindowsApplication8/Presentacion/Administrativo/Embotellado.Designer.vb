﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Embotellado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.tbNumProceso = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbProducto = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.tbProceso = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.tbCodigo = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbCantidad = New System.Windows.Forms.TextBox()
        Me.dgvProceso = New System.Windows.Forms.DataGridView()
        Me.btnIngresar = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.cmbID = New System.Windows.Forms.ComboBox()
        Me.cmbTipo2 = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dtpInicioDescarga = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicioProceso = New System.Windows.Forms.DateTimePicker()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgvBotellas = New System.Windows.Forms.DataGridView()
        CType(Me.dgvProceso, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.dgvBotellas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.Indigo
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button9.Image = Global.WindowsApplication8.My.Resources.Resources.back
        Me.Button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button9.Location = New System.Drawing.Point(6, 389)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(110, 39)
        Me.Button9.TabIndex = 57
        Me.Button9.Text = "Atrás"
        Me.Button9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button9.UseVisualStyleBackColor = False
        '
        'tbNumProceso
        '
        Me.tbNumProceso.Location = New System.Drawing.Point(93, 111)
        Me.tbNumProceso.Name = "tbNumProceso"
        Me.tbNumProceso.Size = New System.Drawing.Size(121, 20)
        Me.tbNumProceso.TabIndex = 139
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(2, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 138
        Me.Label3.Text = "N° Proceso"
        '
        'tbProducto
        '
        Me.tbProducto.Location = New System.Drawing.Point(93, 60)
        Me.tbProducto.Name = "tbProducto"
        Me.tbProducto.Size = New System.Drawing.Size(121, 20)
        Me.tbProducto.TabIndex = 132
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(3, 88)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(60, 13)
        Me.Label49.TabIndex = 137
        Me.Label49.Text = "ID Proceso"
        '
        'tbProceso
        '
        Me.tbProceso.Location = New System.Drawing.Point(93, 85)
        Me.tbProceso.Name = "tbProceso"
        Me.tbProceso.Size = New System.Drawing.Size(121, 20)
        Me.tbProceso.TabIndex = 136
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(2, 140)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(64, 13)
        Me.Label45.TabIndex = 135
        Me.Label45.Text = "Fecha inicio"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(3, 64)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(64, 13)
        Me.Label43.TabIndex = 133
        Me.Label43.Text = "ID Producto"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(4, 38)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(40, 13)
        Me.Label35.TabIndex = 131
        Me.Label35.Text = "Codigo"
        '
        'tbCodigo
        '
        Me.tbCodigo.Location = New System.Drawing.Point(92, 34)
        Me.tbCodigo.Name = "tbCodigo"
        Me.tbCodigo.Size = New System.Drawing.Size(121, 20)
        Me.tbCodigo.TabIndex = 130
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 95)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 141
        Me.Label5.Text = "Fecha"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(4, 118)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 13)
        Me.Label9.TabIndex = 144
        Me.Label9.Text = "Cantidad"
        '
        'tbCantidad
        '
        Me.tbCantidad.Location = New System.Drawing.Point(95, 114)
        Me.tbCantidad.Name = "tbCantidad"
        Me.tbCantidad.Size = New System.Drawing.Size(119, 20)
        Me.tbCantidad.TabIndex = 143
        '
        'dgvProceso
        '
        Me.dgvProceso.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.dgvProceso.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvProceso.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvProceso.Location = New System.Drawing.Point(0, 32)
        Me.dgvProceso.Name = "dgvProceso"
        Me.dgvProceso.Size = New System.Drawing.Size(536, 168)
        Me.dgvProceso.TabIndex = 145
        '
        'btnIngresar
        '
        Me.btnIngresar.BackColor = System.Drawing.Color.Indigo
        Me.btnIngresar.Enabled = False
        Me.btnIngresar.FlatAppearance.BorderSize = 0
        Me.btnIngresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnIngresar.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIngresar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnIngresar.Image = Global.WindowsApplication8.My.Resources.Resources.apply
        Me.btnIngresar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnIngresar.Location = New System.Drawing.Point(120, 390)
        Me.btnIngresar.Name = "btnIngresar"
        Me.btnIngresar.Size = New System.Drawing.Size(122, 37)
        Me.btnIngresar.TabIndex = 146
        Me.btnIngresar.Text = "Ingresar"
        Me.btnIngresar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnIngresar.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(2, 166)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(84, 13)
        Me.Label11.TabIndex = 151
        Me.Label11.Text = "Fecha descarga"
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.dtpFecha)
        Me.Panel4.Controls.Add(Me.cmbID)
        Me.Panel4.Controls.Add(Me.cmbTipo2)
        Me.Panel4.Controls.Add(Me.Label14)
        Me.Panel4.Controls.Add(Me.Label15)
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.tbCantidad)
        Me.Panel4.Location = New System.Drawing.Point(6, 11)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(240, 150)
        Me.Panel4.TabIndex = 154
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(95, 89)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(120, 20)
        Me.dtpFecha.TabIndex = 159
        Me.dtpFecha.Value = New Date(2018, 10, 22, 18, 37, 33, 0)
        '
        'cmbID
        '
        Me.cmbID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbID.FormattingEnabled = True
        Me.cmbID.Location = New System.Drawing.Point(95, 37)
        Me.cmbID.Name = "cmbID"
        Me.cmbID.Size = New System.Drawing.Size(120, 21)
        Me.cmbID.TabIndex = 152
        '
        'cmbTipo2
        '
        Me.cmbTipo2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTipo2.FormattingEnabled = True
        Me.cmbTipo2.Items.AddRange(New Object() {"Tinto", "Rosado", "Blanco"})
        Me.cmbTipo2.Location = New System.Drawing.Point(95, 61)
        Me.cmbTipo2.Name = "cmbTipo2"
        Me.cmbTipo2.Size = New System.Drawing.Size(120, 21)
        Me.cmbTipo2.TabIndex = 150
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(3, 40)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 13)
        Me.Label14.TabIndex = 148
        Me.Label14.Text = "ID Botella"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(3, 67)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(66, 13)
        Me.Label15.TabIndex = 151
        Me.Label15.Text = "Tipo de vino"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Indigo
        Me.Panel5.Controls.Add(Me.Label6)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(238, 28)
        Me.Panel5.TabIndex = 87
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label6.Location = New System.Drawing.Point(3, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(101, 16)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "EMBOTELLADO"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.dtpInicioDescarga)
        Me.Panel1.Controls.Add(Me.dtpInicioProceso)
        Me.Panel1.Controls.Add(Me.Panel6)
        Me.Panel1.Controls.Add(Me.tbCodigo)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.tbProceso)
        Me.Panel1.Controls.Add(Me.tbProducto)
        Me.Panel1.Controls.Add(Me.tbNumProceso)
        Me.Panel1.Controls.Add(Me.Label45)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label49)
        Me.Panel1.Controls.Add(Me.Label43)
        Me.Panel1.Location = New System.Drawing.Point(6, 177)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(237, 207)
        Me.Panel1.TabIndex = 155
        '
        'dtpInicioDescarga
        '
        Me.dtpInicioDescarga.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicioDescarga.Location = New System.Drawing.Point(92, 163)
        Me.dtpInicioDescarga.Name = "dtpInicioDescarga"
        Me.dtpInicioDescarga.Size = New System.Drawing.Size(121, 20)
        Me.dtpInicioDescarga.TabIndex = 159
        Me.dtpInicioDescarga.Value = New Date(2018, 10, 22, 18, 37, 33, 0)
        '
        'dtpInicioProceso
        '
        Me.dtpInicioProceso.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicioProceso.Location = New System.Drawing.Point(92, 137)
        Me.dtpInicioProceso.Name = "dtpInicioProceso"
        Me.dtpInicioProceso.Size = New System.Drawing.Size(121, 20)
        Me.dtpInicioProceso.TabIndex = 158
        Me.dtpInicioProceso.Value = New Date(2018, 10, 22, 18, 37, 33, 0)
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Indigo
        Me.Panel6.Controls.Add(Me.Label2)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(235, 28)
        Me.Panel6.TabIndex = 87
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Location = New System.Drawing.Point(3, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 16)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "DATOS PROCESO"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.Panel8)
        Me.Panel7.Controls.Add(Me.dgvProceso)
        Me.Panel7.Location = New System.Drawing.Point(253, 179)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(538, 205)
        Me.Panel7.TabIndex = 156
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Indigo
        Me.Panel8.Controls.Add(Me.Label7)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel8.Location = New System.Drawing.Point(0, 0)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(536, 28)
        Me.Panel8.TabIndex = 87
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label7.Location = New System.Drawing.Point(3, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(162, 16)
        Me.Label7.TabIndex = 38
        Me.Label7.Text = "PRODUCTO PROCESADO"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Controls.Add(Me.dgvBotellas)
        Me.Panel2.Location = New System.Drawing.Point(254, 11)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(538, 150)
        Me.Panel2.TabIndex = 157
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Indigo
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(536, 28)
        Me.Panel3.TabIndex = 87
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(3, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 16)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "TIPOS DE BOTELLA"
        '
        'dgvBotellas
        '
        Me.dgvBotellas.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.dgvBotellas.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvBotellas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBotellas.Location = New System.Drawing.Point(0, 32)
        Me.dgvBotellas.Name = "dgvBotellas"
        Me.dgvBotellas.Size = New System.Drawing.Size(536, 113)
        Me.dgvBotellas.TabIndex = 145
        '
        'Embotellado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(801, 456)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.btnIngresar)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel7)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Embotellado"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.dgvProceso, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.dgvBotellas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button9 As Button
    Friend WithEvents tbNumProceso As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents tbProducto As TextBox
    Friend WithEvents Label49 As Label
    Friend WithEvents tbProceso As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents tbCodigo As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents tbCantidad As TextBox
    Friend WithEvents dgvProceso As DataGridView
    Friend WithEvents btnIngresar As Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents cmbTipo2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents cmbID As System.Windows.Forms.ComboBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents dgvBotellas As DataGridView
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents dtpInicioDescarga As DateTimePicker
    Friend WithEvents dtpInicioProceso As DateTimePicker
End Class
