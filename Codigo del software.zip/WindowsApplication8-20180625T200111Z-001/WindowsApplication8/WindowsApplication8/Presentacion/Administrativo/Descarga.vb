﻿Public Class Descarga

    Private Sub btnIngresar_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresar.Click
        Recipiente(tbCodigo.Text, tbUnidad2.Text, tbNomRecipiente.Text, tbCapacidad.Text, tbMaterial.Text)
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub tbCodigo_MouseMove(sender As Object, e As MouseEventArgs) Handles tbUnidad2.MouseMove, tbNomRecipiente.MouseMove, tbMaterial.MouseMove, tbCodigo.MouseMove, tbCapacidad.MouseMove
        If String.IsNullOrEmpty(tbNomRecipiente.Text) Or
        String.IsNullOrEmpty(tbCodigo.Text) Or
        String.IsNullOrEmpty(tbUnidad2.Text) Or
        String.IsNullOrEmpty(tbCapacidad.Text) Or
        String.IsNullOrEmpty(tbMaterial.Text) Then
            btnIngresar.Enabled = False
        Else
            btnIngresar.Enabled = True
        End If
    End Sub
End Class