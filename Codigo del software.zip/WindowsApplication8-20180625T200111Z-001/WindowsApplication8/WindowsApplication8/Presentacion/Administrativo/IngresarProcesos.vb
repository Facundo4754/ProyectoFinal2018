﻿Public Class IngresarProcesos
    Private Sub btnIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresar.Click
        Procesos(tbProceso.Text, cmbNumero.Text, tbNombre.Text, cmbTipo.Text)
    End Sub

    Private Sub cmbTipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTipo.SelectedIndexChanged
        Select Case cmbTipo.SelectedItem

            Case "Tinto"
                tbProceso.Text = "01"
            Case "Rosado"
                tbProceso.Text = "02"
            Case "Blanco"
                tbProceso.Text = "03"

        End Select
    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub btnConsultar_Click(sender As Object, e As EventArgs) Handles btnConsultar.Click
        ConsultarProcesos(cmbTipo2.Text)
    End Sub

    Private Sub cmbTipo_MouseMove(sender As Object, e As MouseEventArgs) Handles tbNombre.MouseMove, cmbTipo.MouseMove, cmbNumero.MouseMove
        If String.IsNullOrEmpty(cmbTipo.Text) Or
        String.IsNullOrEmpty(cmbNumero.Text) Or
        String.IsNullOrEmpty(tbNombre.Text) Then
            btnIngresar.Enabled = False
        Else
            btnIngresar.Enabled = True
        End If
    End Sub
End Class