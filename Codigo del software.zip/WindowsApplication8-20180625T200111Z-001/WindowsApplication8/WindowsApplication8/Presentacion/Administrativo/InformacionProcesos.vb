﻿Public Class InformacionProcesos
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        'datos de la tabla pasapor'
        InformacionProceso(cmbProducto.Text, cmbProceso.Text, cmbNumero.Text, dtpFechaInicioProceso.Text, tbUnidad.Text, tbCantidad.Text)

        'datos de la tabla sedescarga'
        DescargaRecipiente(cmbCodigo.Text, cmbProducto.Text, cmbProceso.Text, cmbNumero.Text, dtpFechaInicioProceso.Text, tbCantidad2.Text, dtpFechaInicioDescarga.Text)
    End Sub

    Private Sub InformacionProcesos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Combo4()
        Combo7()
        ConsultarProducto()
    End Sub

    Private Sub cmbProducto_MouseMove(sender As Object, e As MouseEventArgs) Handles tbUnidad.MouseMove, tbCantidad2.MouseMove, tbCantidad.MouseMove, dtpFechaInicioProceso.MouseMove, dtpFechaInicioDescarga.MouseMove, cmbProducto.MouseMove, cmbProceso.MouseMove, cmbNumero.MouseMove, cmbCodigo.MouseMove
        If String.IsNullOrEmpty(cmbProducto.Text) Or
        String.IsNullOrEmpty(cmbProceso.Text) Or
        String.IsNullOrEmpty(cmbNumero.Text) Or
        String.IsNullOrEmpty(tbUnidad.Text) Or
        String.IsNullOrEmpty(tbCantidad.Text) Or
        String.IsNullOrEmpty(cmbCodigo.Text) Or
        String.IsNullOrEmpty(tbCantidad2.Text) Then
            btnIngresar.Enabled = False
        Else
            btnIngresar.Enabled = True
        End If
    End Sub
End Class