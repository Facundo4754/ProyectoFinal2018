﻿Public Class AltaGerentes
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteGMenu.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'datos de la tabla personal'
        Personal(tbCedula.Text, tbNombre.Text, tbApellido.Text, tbDireccion.Text.Trim)

        'datos de la tabla telefonopersonal'
        TelefonoPersonal(tbCedula.Text, tbTelefono1.Text)
            TelefonoPersonal2(tbCedula.Text, tbTelefono2.Text)

        'datos de la tabla gerentes'
        Gerentes(tbCedula.Text, cmbTipo.Text)

        tbCedula.Clear()
        tbNombre.Clear()
        tbApellido.Clear()
        tbTelefono1.Clear()
        tbTelefono2.Clear()
        tbDireccion.Clear()

    End Sub

    Private Sub tbTelefono2_MouseMove(sender As Object, e As MouseEventArgs) Handles tbTelefono2.MouseMove, tbNombre.MouseMove, tbApellido.MouseMove, tbDireccion.MouseMove, tbTelefono1.MouseMove
        If String.IsNullOrEmpty(tbCedula.Text) Or
        String.IsNullOrEmpty(tbNombre.Text) Or
        String.IsNullOrEmpty(tbApellido.Text) Or
        String.IsNullOrEmpty(tbDireccion.Text) Or
        String.IsNullOrEmpty(tbTelefono1.Text) Or
        String.IsNullOrEmpty(tbTelefono2.Text) Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub
End Class