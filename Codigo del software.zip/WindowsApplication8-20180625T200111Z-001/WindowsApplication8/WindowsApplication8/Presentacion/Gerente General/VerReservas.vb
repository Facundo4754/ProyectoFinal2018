﻿Public Class VerReservas
    Private Sub Button9_Click_1(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteGMenu.Show()
    End Sub

    Private Sub VerReservas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConsultaReserva()
    End Sub
End Class