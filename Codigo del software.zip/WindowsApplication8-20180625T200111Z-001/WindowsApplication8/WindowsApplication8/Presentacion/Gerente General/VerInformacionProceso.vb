﻿Public Class VerInformacionProceso
    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Me.Close()
        GerenteGMenu.Show()
    End Sub

    Private Sub VerInformacionProceso_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConsultaInfoProcesos()
    End Sub
End Class