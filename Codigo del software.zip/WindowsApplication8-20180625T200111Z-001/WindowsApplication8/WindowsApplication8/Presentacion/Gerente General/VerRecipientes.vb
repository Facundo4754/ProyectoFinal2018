﻿Public Class VerRecipientes
    Private Sub Button9_Click_1(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteGMenu.Show()
    End Sub

    Private Sub VerRecipientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConsultaRecipientes()
    End Sub
End Class