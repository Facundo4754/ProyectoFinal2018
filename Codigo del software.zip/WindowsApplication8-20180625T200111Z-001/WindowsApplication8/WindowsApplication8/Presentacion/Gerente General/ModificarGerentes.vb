﻿Public Class ModificarGerentes
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteGMenu.Show()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If CheckGerente(tbCI.Text) = True Then
            MsgBox("Gerente Encontrado")
            BuscarGerentes(tbCI.Text)
            tbNombre.Enabled = True
            tbApellido.Enabled = True
            tbTelefono1.Enabled = True
            tbTelefono2.Enabled = True
            tbDireccion.Enabled = True
            tbCI.Enabled = False
            btnModificar.Enabled = True
        Else
            MsgBox("Gerente No Encontrado")
            tbCI.Clear()
            tbNombre.Clear()
            tbApellido.Clear()
            tbTelefono1.Clear()
            tbTelefono2.Clear()
            tbDireccion.Clear()
            tbNombre.Enabled = False
            tbApellido.Enabled = False
            tbTelefono1.Enabled = False
            tbTelefono2.Enabled = False
            tbDireccion.Enabled = False
            btnModificar.Enabled = False
        End If
        
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        ModificacionPersonal(tbCI.Text, tbNombre.Text, tbApellido.Text, tbDireccion.Text)
        tbCI.Clear()
        tbNombre.Clear()
        tbApellido.Clear()
        tbTelefono1.Clear()
        tbTelefono2.Clear()
        tbDireccion.Clear()
        tbNombre.Enabled = False
        tbApellido.Enabled = False
        tbTelefono1.Enabled = False
        tbTelefono2.Enabled = False
        tbDireccion.Enabled = False
        btnModificar.Enabled = False
    End Sub
End Class