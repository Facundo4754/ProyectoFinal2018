﻿Public Class Observaciones
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ConsultaObservacion(tbCedula.Text) = True Then
            MsgBox("Persona Encontrada")
            btnIngresar.Enabled = True
        Else
            MsgBox("Persona No encontrada")
        End If
    End Sub

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        'datos de la tabla interviene'
        IngresoObservaciones(tbCedula.Text, dtpFecha.Text, tbMensaje.Text, tbProducto.Text, tbProceso.Text, cmbNumero.Text, dtpFechaInicio.Text)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ConsultarProducto3()
        ConsultarPasapor()
    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Hide()
        AsesorMenu.Show()
    End Sub
End Class