﻿Imports System.Data.Odbc

Module Conexion
    Public conectar As New Odbc.OdbcConnection
    Public comando As New OdbcCommand
    Public comando2 As New OdbcCommand
    Public comando3 As New OdbcCommand
    Dim dt As New DataTable

    Public Sub abrirConn()

        Try
            conectar.ConnectionString = "FileDsn=" & Application.StartupPath & "\miodbc.dsn;UID=mrosales;;PWD=1234"


            conectar.Open()
        Catch ex As Exception
            MessageBox.Show("Error de conexión" + ex.Message)
        End Try

    End Sub

    Public Sub cerrarConn()
        conectar.Close()
    End Sub

    Public Function login(ByVal usu As String, ByVal cargo As String)

        abrirConn()
        Dim ok As Boolean = False
        Dim dr As Odbc.OdbcDataReader
        Dim sql As String = "SELECT * FROM login WHERE usuario='" & usu & "' AND cargo='" & cargo & "'"
        comando.Connection = conectar
        comando.CommandText = sql
        dr = comando.ExecuteReader()
        If dr.HasRows Then
            ok = True
            cerrarConn()
            Return ok
        Else
            ok = False
            cerrarConn()
            Return ok
        End If
        cerrarConn()

    End Function

    Public Sub Personal(ByVal CI As Integer, ByVal nombre As String, ByVal apellido As String, ByVal direccion As String)

        abrirConn()
        Dim sql As String = "INSERT INTO personal VALUES ('" & CI & "', '" & nombre & "', '" & apellido & "', '" & direccion & "', '" & 0 & "')"
        comando.Connection = conectar
        comando.CommandText = sql
        comando.ExecuteReader()
        cerrarConn()

    End Sub

    Public Sub TelefonoPersonal(ByVal CI As Integer, ByVal telefono1 As Integer)

        abrirConn()
        Dim sql1 As String = "INSERT INTO telefonopersonal VALUES ('" & CI & "', '" & telefono1 & "')"
        comando.Connection = conectar
        comando.CommandText = sql1
        comando.ExecuteReader()
        cerrarConn()

    End Sub

    Public Sub TelefonoPersonal2(ByVal CI As Integer, ByVal telefono2 As Integer)

        'Ventana Gerente de Sucursal / Alta Funcionarios'
        'Ventana Gerente General / Alta Gerentes'
        abrirConn()
        Dim sql17 As String = "INSERT INTO telefonopersonal VALUES ('" & CI & "', '" & telefono2 & "')"
        comando.Connection = conectar
        comando.CommandText = sql17
        comando.ExecuteReader()
        cerrarConn()

    End Sub

    Public Sub Tipo(ByVal CI As Integer, ByVal tipoasesor As String)

        abrirConn()
        If AltaFuncionarios.cmbTipo.SelectedItem = "Asesor" Then
            Try
                Dim sql2 As String = "INSERT INTO asesores VALUES ('" & CI & "', '" & tipoasesor & "')"
                comando.Connection = conectar
                comando.CommandText = sql2
                comando.ExecuteReader()
                MsgBox("se agrego correctamente")
                ' limpiar(AltaFuncionarios)
                cerrarConn()
            Catch ex As Exception
                MsgBox("no se agrego correctamente")
                cerrarConn()
            End Try

        ElseIf AltaFuncionarios.cmbTipo.SelectedItem = "Administrativo" Then
            Try
                Dim sql3 As String = "INSERT INTO administrativos VALUES ('" & CI & "')"
                comando.Connection = conectar
                comando.CommandText = sql3
                comando.ExecuteReader()
                MsgBox("se agrego correctamente")
                cerrarConn()
            Catch ex As Exception
                MsgBox("no se agrego correctamente")
                cerrarConn()
            End Try
        End If

    End Sub

    Public Sub Gerentes(ByVal CI As Integer, ByVal tipogerente As String)

        abrirConn()
        Try
            Dim sql18 As String = "INSERT INTO gerentes VALUES ('" & CI & "', '" & tipogerente & "')"
            comando.Connection = conectar
            comando.CommandText = sql18
            comando.ExecuteReader()
            MsgBox("se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("no se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub Procesos(ByVal idProceso As Integer, ByVal numero As String, ByVal nombre As String, ByVal tipodevino As String)

        abrirConn()
        Try
            Dim sql16 As String = "INSERT INTO procesos VALUES ('" & idProceso & "', '" & numero & "', '" & nombre & "', '" & tipodevino & "')"
            comando.Connection = conectar
            comando.CommandText = sql16
            comando.ExecuteReader()
            MsgBox("se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("no se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub InformacionProceso(ByVal idProducto As Integer, ByVal idProceso As Integer, ByVal numero As Integer, ByVal fechainicio As Date, ByVal unidad As String, ByVal cantidad As Integer)

        abrirConn()
        Try
            Dim sql4 As String = "INSERT INTO pasapor VALUES ('" & idProducto & "', '" & idProceso & "', '" & numero & "',  '" & fechainicio & "', '" & DBNull.Value & "', '" & unidad & "', '" & cantidad & "')"
            comando.Connection = conectar
            comando.CommandText = sql4
            comando.ExecuteReader()
            cerrarConn()
        Catch ex As Exception
            MsgBox("no se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub Recipiente(ByVal codigo As Integer, ByVal unidad As String, ByVal nombre As String, ByVal capacidad As Integer, ByVal material As String)

        abrirConn()
        Try
            Dim sql6 As String = "INSERT INTO recipiente VALUES ('" & codigo & "', '" & unidad & "', '" & nombre & "', '" & capacidad & "', '" & material & "')"
            comando.Connection = conectar
            comando.CommandText = sql6
            comando.ExecuteReader()
            MsgBox("se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("no se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub DescargaRecipiente(ByVal codigo As Integer, ByVal idProducto As Integer, ByVal idProceso As Integer, ByVal numero As Integer, ByVal fechainicioproceso As Date, ByVal cantidad As Integer, ByVal fechainicio As Date)

        abrirConn()
        Try
            Dim sql7 As String = "INSERT INTO sedescarga VALUES ('" & codigo & "', '" & idProducto & "', '" & idProceso & "', '" & numero & "', '" & fechainicioproceso & "', '" & cantidad & "', '" & fechainicio & "', '" & DBNull.Value & "')"
            comando.Connection = conectar
            comando.CommandText = sql7
            comando.ExecuteReader()
            MsgBox("se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("no se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub AltaProducto(ByVal idProducto As Integer, ByVal tipoprod As String, ByVal cepa As String, ByVal estado As String)

        abrirConn()
            Dim sql8 As String = "INSERT INTO producto VALUES ('" & idProducto & "', '" & tipoprod & "', '" & cepa & "', '" & estado & "')"
            comando.Connection = conectar
            comando.CommandText = sql8
            comando.ExecuteReader()
        cerrarConn()

    End Sub

    Public Sub Transportes(ByVal idProducto As Integer, ByVal idLugar As Integer, ByVal fecha As Date, ByVal matricula As String, ByVal cantidad As Integer, ByVal capacidad As Integer)

        abrirConn()
        Try
            Dim sql9 As String = "INSERT INTO transporta VALUES ('" & idProducto & "', '" & idLugar & "', '" & fecha & "', '" & matricula & "', '" & cantidad & "', '" & capacidad & "')"
            comando.Connection = conectar
            comando.CommandText = sql9
            comando.ExecuteReader()
            MsgBox("Se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("Error: no se agrego")
            cerrarConn()
        End Try

    End Sub

    Public Sub Lugar(ByVal idLugar As Integer, ByVal propioajeno As String)

        abrirConn()
        Try
            Dim sql10 As String = "INSERT INTO lugar VALUES ('" & idLugar & "', '" & propioajeno & "')"
            comando.Connection = conectar
            comando.CommandText = sql10
            comando.ExecuteReader()
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub Parcela(ByVal idLugar As Integer, ByVal numparcela As Integer)

        abrirConn()
        Try
            Dim sql11 As String = "INSERT INTO parcela VALUES ('" & idLugar & "', '" & numparcela & "')"
            comando.Connection = conectar
            comando.CommandText = sql11
            comando.ExecuteReader()
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub Bodega(ByVal idLugar As Integer, ByVal nombrebodega As String, ByVal numsucursal As Integer)

        abrirConn()
        Try
            Dim sql12 As String = "INSERT INTO bodega VALUES ('" & idLugar & "', '" & nombrebodega & "', '" & numsucursal & "')"
            comando.Connection = conectar
            comando.CommandText = sql12
            comando.ExecuteReader()
            MsgBox("Se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("Error: no se agrego")
            cerrarConn()
        End Try

    End Sub

    Public Sub Cliente(ByVal CI As Integer, ByVal nombre As String, ByVal apellido As String, ByVal direccion As String)

        abrirConn()
        Dim sql13 As String = "INSERT INTO cliente VALUES ('" & CI & "', '" & nombre & "', '" & apellido & "', '" & direccion & "')"
        comando.Connection = conectar
        comando.CommandText = sql13
        comando.ExecuteReader()
        cerrarConn()

    End Sub

    Public Sub TelefonoCliente(ByVal CI As Integer, ByVal telefono1 As Integer)

        abrirConn()
        Dim sql14 As String = "INSERT INTO telefonocliente VALUES ('" & CI & "', '" & telefono1 & "')"
        comando.Connection = conectar
        comando.CommandText = sql14
        comando.ExecuteReader()
        cerrarConn()

    End Sub

    Public Sub TelefonoCliente2(ByVal CI As Integer, ByVal telefono2 As Integer)

        abrirConn()
        Try
            Dim sql21 As String = "INSERT INTO telefonocliente VALUES ('" & CI & "', '" & telefono2 & "')"
            comando.Connection = conectar
            comando.CommandText = sql21
            comando.ExecuteReader()
            MsgBox("Cliente ingresado")
            cerrarConn()
        Catch ex As Exception
            MsgBox("Error: Cliente no ingresado")
            cerrarConn()
        End Try

    End Sub

    Public Sub Reserva(ByVal CI As Integer, ByVal IdBotella As Integer, ByVal tipodevino As String, ByVal vencimiento As Date, ByVal cantidad As Integer, ByVal fecha As Date)

        abrirConn()
        Try
            Dim sql15 As String = "INSERT INTO reserva VALUES ('" & CI & "', '" & IdBotella & "', '" & tipodevino & "', '" & vencimiento & "', '" & cantidad & "', '" & fecha & "')"
            comando.Connection = conectar
            comando.CommandText = sql15
            comando.ExecuteReader()
            MsgBox("se agrego correctamente")
        Catch ex As Exception
            MsgBox("no se agrego correctamente")
        End Try
        cerrarConn()

    End Sub

    Public Function ConsultaBaja(ByVal CI As Integer) As Boolean

        abrirConn()
        Dim dr As Odbc.OdbcDataReader
        Dim dr2 As Odbc.OdbcDataReader
        Dim encontre As Boolean
        encontre = False
        Dim aux As String
        Try
            Dim sql As String = "SELECT * FROM gerentes WHERE ciPersonal='" & CI & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            dr2 = comando.ExecuteReader()

            If (Not dr2.HasRows) Then
                Dim sql20 As String = "SELECT * FROM personal WHERE ciPersonal='" & CI & "' and eliminado='" & 0 & "'"
                comando2.Connection = conectar
                comando2.CommandText = sql20
                dr = comando2.ExecuteReader()
                dr.Read()
                aux = dr("ciPersonal")
                If CI = aux Then
                    encontre = True
                End If
                cerrarConn()
                Return encontre
            Else
                cerrarConn()
                Return encontre

            End If
        Catch ex As Exception
            cerrarConn()
            Return encontre
        End Try

    End Function

    Public Function ConsultaBaja2(ByVal CI As Integer) As Boolean

        abrirConn()
        Dim dr As Odbc.OdbcDataReader
        Dim dr2 As Odbc.OdbcDataReader
        Dim encontre As Boolean
        encontre = False
        Dim aux As String
        Try
            Dim sql As String = "SELECT * FROM gerentes WHERE ciPersonal='" & CI & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            dr2 = comando.ExecuteReader()

            If (dr2.HasRows) Then
                Dim sql20 As String = "SELECT * FROM personal WHERE ciPersonal='" & CI & "' and eliminado='" & 0 & "'"
                comando2.Connection = conectar
                comando2.CommandText = sql20
                dr = comando2.ExecuteReader()
                dr.Read()
                aux = dr("ciPersonal")
                If CI = aux Then
                    encontre = True
                End If
                cerrarConn()
                Return encontre
            Else
                cerrarConn()
                Return encontre

            End If
        Catch ex As Exception
            cerrarConn()
            Return encontre
        End Try

    End Function

    Public Sub BajaPersonal(ByVal CI As Integer)

        abrirConn()
        Try
            Dim sql19 As String = "UPDATE personal SET eliminado='" & 1 & "' WHERE ciPersonal='" & CI & "'"
            comando.Connection = conectar
            comando.CommandText = sql19
            comando.ExecuteReader()
            MsgBox("Se dio de baja correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("No se dio de baja")
            cerrarConn()
        End Try

    End Sub

    Public Function BuscarGerentes(ByVal CI As Integer)

        abrirConn()
        Dim dr As Odbc.OdbcDataReader
        Dim dr2 As Odbc.OdbcDataReader
        Try
            Dim sql As String = "SELECT * FROM personal WHERE ciPersonal='" & CI & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            dr = comando.ExecuteReader()
            If dr.HasRows Then
                ModificarGerentes.tbNombre.Text = dr("nombre")
                ModificarGerentes.tbApellido.Text = dr("apellido")
                ModificarGerentes.tbDireccion.Text = dr("direccion")
            End If

            Dim sql2 As String = "SELECT * FROM telefonopersonal WHERE ciPersonal='" & CI & "'"
            comando3.Connection = conectar
            comando3.CommandText = sql2
            dr2 = comando3.ExecuteReader()
            Dim a As Integer
            Dim i As Integer
            i = 0
            While dr2.Read
                a = dr2("telefono")
                If i = 0 Then
                    ModificarGerentes.tbTelefono1.Text = a
                Else
                    ModificarGerentes.tbTelefono2.Text = a
                End If
                i = i + 1
            End While
            cerrarConn()
        Catch ex As Exception
            MsgBox("Persona no encontrada")
            cerrarConn()
        End Try

    End Function

    Public Function BuscarFuncionario(ByVal CI As Integer)

        abrirConn()
        Dim dr As Odbc.OdbcDataReader
        Dim dr2 As Odbc.OdbcDataReader
        Try
            Dim sql As String = "SELECT * FROM personal WHERE ciPersonal='" & CI & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            dr = comando.ExecuteReader()
            If dr.HasRows Then
                ModificarFuncionarios.tbNombre.Text = dr("nombre")
                ModificarFuncionarios.tbApellido.Text = dr("apellido")
                ModificarFuncionarios.tbDireccion.Text = dr("direccion")
            End If

            Dim sql2 As String = "SELECT * FROM telefonopersonal WHERE ciPersonal='" & CI & "'"
            comando3.Connection = conectar
            comando3.CommandText = sql2
            dr2 = comando3.ExecuteReader()
            Dim a As Integer
            Dim i As Integer
            i = 0
            While dr2.Read
                a = dr2("telefono")
                If i = 0 Then
                    ModificarFuncionarios.tbTelefono1.Text = a
                Else
                    ModificarFuncionarios.tbTelefono2.Text = a
                End If
                i = i + 1
            End While
            cerrarConn()
        Catch ex As Exception
            MsgBox("Persona no encontrada")
            cerrarConn()
        End Try

    End Function

    Public Function CheckGerente(ByVal CI As Integer)

        abrirConn()
        Dim dr2 As Odbc.OdbcDataReader
        Dim encontre As Boolean
        encontre = False
        Try
            Dim sql As String = "SELECT * FROM gerentes WHERE ciPersonal='" & CI & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            dr2 = comando.ExecuteReader()

            If (dr2.HasRows) Then
                encontre = True
                cerrarConn()
                Return encontre
            Else
                cerrarConn()
                Return encontre
            End If
        Catch ex As Exception
            cerrarConn()
            Return encontre
        End Try

    End Function

    Public Function CheckFuncionario(ByVal CI As Integer)

        abrirConn()
        Dim dr2 As Odbc.OdbcDataReader
        Dim encontre As Boolean
        encontre = False
        Try
            Dim sql As String = "SELECT * FROM gerentes WHERE ciPersonal='" & CI & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            dr2 = comando.ExecuteReader()

            If (dr2.HasRows) Then
                encontre = True
                cerrarConn()
                Return encontre
            Else
                cerrarConn()
                Return encontre
            End If
        Catch ex As Exception
            cerrarConn()
            Return encontre
        End Try

    End Function

    Public Sub ModificacionPersonal(ByVal CI As Integer, ByVal nombre As String, ByVal apellido As String, ByVal direccion As String)

        abrirConn()
        Try
            Dim sql19 As String = "UPDATE personal SET nombre='" & nombre & "', apellido='" & apellido & "', direccion='" & direccion & "' WHERE ciPersonal='" & CI & "' AND eliminado='" & 0 & "'"
            comando.Connection = conectar
            comando.CommandText = sql19
            comando.ExecuteReader()
            MsgBox("Se modifico correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("No se modifico correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultaReserva()

        abrirConn()
        Dim sql As String = "SELECT * FROM reserva"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        VerReservas.dgvReserva.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultaInfoProcesos()

        abrirConn()
        Dim sql As String = "SELECT * FROM pasapor"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        VerInformacionProceso.dgvInfoProcesos.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultaRecipientes()

        abrirConn()
        Dim sql As String = "SELECT * FROM recipiente"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        VerRecipientes.dgvRecipientes.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Function ConsultaObservacion(ByVal CI As Integer) As Boolean

        abrirConn()
        Dim dr As Odbc.OdbcDataReader
        Dim encontre As Boolean
        encontre = False
        Dim aux As String
        Try
            Dim sql24 As String = "SELECT * FROM personal WHERE ciPersonal='" & CI & "' and eliminado='" & 0 & "'"
            comando.Connection = conectar
            comando.CommandText = sql24
            dr = comando.ExecuteReader()
            dr.Read()
            aux = dr("ciPersonal")
            If CI = aux Then
                encontre = True
            End If
            cerrarConn()
            Return encontre
        Catch ex As Exception
            cerrarConn()
            Return encontre
        End Try

    End Function

    Public Sub IngresoObservaciones(ByVal CI As Integer, ByVal fecha As Date, ByVal observaciones As String, ByVal idProducto As Integer, ByVal idProceso As Integer, ByVal numero As Integer, ByVal fechainicioproceso As Date)

        abrirConn()
        Try
            Dim sql25 As String = "INSERT INTO interviene VALUES ('" & CI & "', '" & fecha & "', '" & observaciones & "', '" & idProducto & "', '" & idProceso & "', '" & numero & "', '" & fechainicioproceso & "')"
            comando.Connection = conectar
            comando.CommandText = sql25
            comando.ExecuteReader()
            MsgBox("se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("no se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultarProcesos(ByVal tipo As String)

        abrirConn()
        Try
            If IngresarProcesos.cmbTipo2.SelectedItem = "Tinto" Then
                tipo = "1"
            ElseIf IngresarProcesos.cmbTipo2.SelectedItem = "Rosado" Then
                tipo = "2"
            Else
                tipo = "3"
            End If

            Dim sql26 As String = "SELECT * FROM procesos WHERE idProceso='" & tipo & "'"
            comando.Connection = conectar
            comando.CommandText = sql26
            Dim da As New OdbcDataAdapter(sql26, conectar)
            Dim ds As New DataSet
            da.Fill(ds)
            IngresarProcesos.dgvProcesos.DataSource = ds.Tables(0)
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultarProducto()

        abrirConn()
        Dim sql27 As String = "SELECT * FROM producto"
        comando.Connection = conectar
        comando.CommandText = sql27
        Dim da As New Odbc.OdbcDataAdapter(sql27, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        InformacionProcesos.dgvProducto.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultarProducto2()

        abrirConn()
        Dim sql28 As String = "SELECT * FROM producto"
        comando.Connection = conectar
        comando.CommandText = sql28
        Dim da As New Odbc.OdbcDataAdapter(sql28, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        ConsultaStock.dgvProducto.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultarProducto3()

        abrirConn()
        Dim sql29 As String = "SELECT * FROM producto"
        comando.Connection = conectar
        comando.CommandText = sql29
        Dim da As New Odbc.OdbcDataAdapter(sql29, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        Observaciones.dgvProducto.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultarPasapor()

        abrirConn()
        Dim sql30 As String = "SELECT * FROM pasapor"
        comando.Connection = conectar
        comando.CommandText = sql30
        Dim da As New Odbc.OdbcDataAdapter(sql30, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        Observaciones.dgvPasapor.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub TipoBotella(ByVal idTipo As Integer, ByVal tipodevino As String, ByVal capacidad As Decimal)

        abrirConn()
        Try
            Dim sql As String = "INSERT INTO tipodebotella VALUES ('" & idTipo & "', '" & tipodevino & "', '" & capacidad & "', '" & 0 & "')"
            comando.Connection = conectar
            comando.CommandText = sql
            comando.ExecuteReader()
            cerrarConn()
            MsgBox("se agrego correctamente")
        Catch ex As Exception
            MsgBox("No se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub Embotella(ByVal idTipo As Integer, ByVal tipodevino As String, ByVal codigo As Integer, ByVal idproducto As Integer, ByVal idproceso As Integer, ByVal numero As Integer, ByVal fechainicioproceso As Date, ByVal fechainiciodescarga As Date, ByVal fecha As Date, ByVal cantidad As Integer)

        abrirConn()
        Try
            Dim sql As String = "INSERT INTO embotella VALUES ('" & idTipo & "', '" & tipodevino & "', '" & codigo & "', '" & idproducto & "', '" & idproceso & "', '" & numero & "', '" & fechainicioproceso & "', '" & fechainiciodescarga & "','" & fecha & "', '" & cantidad & "')"
            comando.Connection = conectar
            comando.CommandText = sql
            comando.ExecuteReader()
            MsgBox("Se agrego correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("No se agrego correctamente")
            cerrarConn()
        End Try

    End Sub

    Public Sub SumarStock(ByVal cantidad As Integer, ByVal idbotella As Integer)

        abrirConn()
        Try
            Dim sql As String = "UPDATE tipodebotella SET stock=stock+'" & cantidad & "' WHERE idtipobotella='" & idbotella & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            comando.ExecuteReader()
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub RestarStock(ByVal cantidad As Integer, ByVal idbotella As Integer)

        abrirConn()
        Try
            Dim sql As String = "UPDATE tipodebotella SET stock=stock-'" & cantidad & "' WHERE idtipobotella='" & idbotella & "'"
            comando.Connection = conectar
            comando.CommandText = sql
            comando.ExecuteReader()
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultaSeDescarga()

        abrirConn()
        Dim sql As String = "SELECT * FROM sedescarga"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        Embotellado.dgvProceso.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultaPersonal()

        abrirConn()
        Dim sql As String = "SELECT * FROM personal"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        VerFuncionarios.dgvPersonal.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultaTelefonoPersonal()

        abrirConn()
        Dim sql As String = "SELECT * FROM telefonopersonal"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        VerFuncionarios.dgvTelefonos.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub ConsultarProcesos2(ByVal tipo As String)

        abrirConn()
        Try
            If VerProcesos.cmbTipo.SelectedItem = "Tinto" Then
                tipo = "1"
            ElseIf VerProcesos.cmbTipo.SelectedItem = "Rosado" Then
                tipo = "2"
            Else
                tipo = "3"
            End If

            Dim sql26 As String = "SELECT * FROM procesos WHERE idProceso='" & tipo & "'"
            comando.Connection = conectar
            comando.CommandText = sql26
            Dim da As New OdbcDataAdapter(sql26, conectar)
            Dim ds As New DataSet
            da.Fill(ds)
            VerProcesos.dgvProcesos.DataSource = ds.Tables(0)
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultarProducto2(ByVal tipo As String)

        abrirConn()
        Try
            If VerProducto.cmbTipo.SelectedItem = "Materia Prima" Then
                tipo = "Materia Prima"
            Else
                VerProcesos.cmbTipo.SelectedItem = "Producto Intermedio"
                tipo = "Producto Intermedio"
            End If

            Dim sql26 As String = "SELECT * FROM producto WHERE tipo='" & tipo & "'"
            comando.Connection = conectar
            comando.CommandText = sql26
            Dim da As New OdbcDataAdapter(sql26, conectar)
            Dim ds As New DataSet
            da.Fill(ds)
            VerProducto.dgvProducto.DataSource = ds.Tables(0)
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultarBotellaTinto()

        abrirConn()
        Try
            Dim sql As String = "SELECT * FROM tipodebotella WHERE tipodevino ='Tinto'"
            comando.Connection = conectar
            comando.CommandText = sql
            Dim da As New OdbcDataAdapter(sql, conectar)
            Dim ds As New DataSet
            da.Fill(ds)
            ConsultaStock.dgvProducto.DataSource = ds.Tables(0)
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultarBotellaBlanco()

        abrirConn()
        Try
            Dim sql As String = "SELECT * FROM tipodebotella WHERE tipodevino ='Blanco'"
            comando.Connection = conectar
            comando.CommandText = sql
            Dim da As New OdbcDataAdapter(sql, conectar)
            Dim ds As New DataSet
            da.Fill(ds)
            ConsultaStock.dgvProducto.DataSource = ds.Tables(0)
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultarBotellaRosado()

        abrirConn()
        Try
            Dim sql As String = "SELECT * FROM tipodebotella WHERE tipodevino ='Rosado'"
            comando.Connection = conectar
            comando.CommandText = sql
            Dim da As New OdbcDataAdapter(sql, conectar)
            Dim ds As New DataSet
            da.Fill(ds)
            ConsultaStock.dgvProducto.DataSource = ds.Tables(0)
            cerrarConn()
        Catch ex As Exception
            cerrarConn()
        End Try

    End Sub

    Public Sub ConsultaBotellas()

        abrirConn()
        Dim sql As String = "SELECT * FROM tipodebotella"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        Embotellado.dgvBotellas.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub Combo1()

        abrirConn()
        Dim sql As String = "SELECT idtipobotella FROM tipodebotella"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        DatosReserva.cmbIdBotella.DataSource = ds.Tables(0)
        DatosReserva.cmbIdBotella.DisplayMember = "idtipobotella"
        DatosReserva.cmbIdBotella.ValueMember = "idtipobotella"
        cerrarConn()

    End Sub

    Public Sub Combo2()

        abrirConn()
        Dim sql As String = "SELECT idlugar FROM lugar"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        IngresoMateria.cmbLugar.DataSource = ds.Tables(0)
        IngresoMateria.cmbLugar.DisplayMember = "idlugar"
        IngresoMateria.cmbLugar.ValueMember = "idlugar"
        cerrarConn()

    End Sub

    Public Sub Combo3()

        abrirConn()
        Dim sql As String = "SELECT idlugar FROM lugar"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        IngresoIntermedio.cmbLugar.DataSource = ds.Tables(0)
        IngresoIntermedio.cmbLugar.DisplayMember = "idlugar"
        IngresoIntermedio.cmbLugar.ValueMember = "idlugar"
        cerrarConn()

    End Sub

    Public Sub Combo4()

        abrirConn()
        Dim sql As String = "SELECT idproducto FROM producto"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        InformacionProcesos.cmbProducto.DataSource = ds.Tables(0)
        InformacionProcesos.cmbProducto.DisplayMember = "idproducto"
        InformacionProcesos.cmbProducto.ValueMember = "idproducto"
        cerrarConn()

    End Sub

    Public Sub Combo5()

        abrirConn()
        Dim sql As String = "SELECT * FROM tipodebotella"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        Embotellado.cmbID.DataSource = ds.Tables(0)
        Embotellado.cmbID.DisplayMember = "idtipobotella"
        Embotellado.cmbID.ValueMember = "idtipobotella"
        cerrarConn()

    End Sub

    Public Sub Combo7()

        abrirConn()
        Dim sql As String = "SELECT codigo FROM recipiente"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        InformacionProcesos.cmbCodigo.DataSource = ds.Tables(0)
        InformacionProcesos.cmbCodigo.DisplayMember = "codigo"
        InformacionProcesos.cmbCodigo.ValueMember = "codigo"
        cerrarConn()

    End Sub

    Public Sub FechaFinalProceso(ByVal fechafinal As Date, ByVal idproducto As Integer, ByVal idproceso As Integer, ByVal numero As Integer)

        abrirConn()
        Try
            Dim sql19 As String = "UPDATE pasapor SET fechafinalizacion='" & fechafinal & "' WHERE idproducto='" & idproducto & "' AND idproceso='" & idproceso & "' AND numero='" & numero & "'"
            comando.Connection = conectar
            comando.CommandText = sql19
            comando.ExecuteReader()
            MsgBox("Se finalizo correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("No se actualizo")
            cerrarConn()
        End Try

    End Sub

    Public Sub FechaFinalDescarga(ByVal fechafinal As Date, ByVal codigo As Integer)

        abrirConn()
        Try
            Dim sql19 As String = "UPDATE sedescarga SET fechafinalizacion='" & fechafinal & "' WHERE codigo='" & codigo & "'"
            comando.Connection = conectar
            comando.CommandText = sql19
            comando.ExecuteReader()
            MsgBox("Se finalizo correctamente")
            cerrarConn()
        Catch ex As Exception
            MsgBox("No se actualizo")
            cerrarConn()
        End Try

    End Sub

    Public Function GraficoTipoProducto()

        abrirConn()
        Dim items As New ArrayList
        Dim dr As Odbc.OdbcDataReader
        Dim sql24 As String = "SELECT tipo, count (tipo) FROM producto group by tipo order by tipo"
        comando.Connection = conectar
        comando.CommandText = sql24
        dr = comando.ExecuteReader
        While dr.Read
            Dim item() As String = {dr("tipo"), dr(1)}
            items.Add(item)
        End While
        Return items

    End Function

    Public Function GraficoCepas()

        Dim items As New ArrayList
        Dim dr As Odbc.OdbcDataReader
        Dim sql24 As String = "SELECT cepa, count (tipo) FROM producto group by cepa order by cepa"
        comando2.Connection = conectar
        comando2.CommandText = sql24
        dr = comando2.ExecuteReader
        While dr.Read
            Dim item() As String = {dr("cepa"), dr(1)}
            items.Add(item)
        End While
        Return items
        cerrarConn()

    End Function

    Public Sub ConsultarObservaciones()

        Dim sql As String = "SELECT idproducto, idproceso, numero, observaciones, fecha FROM interviene WHERE fecha=TODAY"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        VObservaciones.dgvObservaciones.DataSource = ds.Tables(0)
        cerrarConn()

    End Sub

    Public Sub IngresarAlertas(ByVal id As Integer, ByVal fecha As Date, ByVal alerta As String)

        abrirConn()
        Try
            Dim sql25 As String = "INSERT INTO alertas VALUES ('" & id & "', '" & fecha & "', '" & alerta & "')"
            comando.Connection = conectar
            comando.CommandText = sql25
            comando.ExecuteReader()
            MsgBox("Se agrego alerta ")
            cerrarConn()
        Catch ex As Exception
            MsgBox("No se agrego alerta")
            cerrarConn()
        End Try

    End Sub

    Public Sub VerAlerta(ByVal id As Integer)

        abrirConn()
        Dim dr As Odbc.OdbcDataReader
        Dim sql As String = "SELECT * FROM alertas WHERE id='" & id & "'"
        comando2.Connection = conectar
        comando2.CommandText = sql
        dr = comando2.ExecuteReader()

        If dr.HasRows Then
            MsgBox(dr("alerta"))
            ' AdminMenu.lblPrueba.Text = dr("alerta")
        End If
        cerrarConn()

    End Sub

    Public Sub CantidadAlertas()

        abrirConn()
        Dim dr As Odbc.OdbcDataReader
        Dim sql As String = "select count (id) as cantidad from alertas"
        comando2.Connection = conectar
        comando2.CommandText = sql
        dr = comando2.ExecuteReader()
        If dr.HasRows Then
            AdminMenu.lblCantidad.Text = dr("cantidad")
        Else
            AdminMenu.lblCantidad.Text = "0"
        End If
        cerrarConn()

    End Sub

    Public Sub Combo6()

        abrirConn()
        Dim sql As String = "SELECT id FROM alertas"
        comando.Connection = conectar
        comando.CommandText = sql
        Dim da As New Odbc.OdbcDataAdapter(sql, conectar)
        Dim ds As New DataSet
        da.Fill(ds)
        AdminMenu.cmbID.DataSource = ds.Tables(0)
        AdminMenu.cmbID.DisplayMember = "id"
        AdminMenu.cmbID.ValueMember = "id"
        cerrarConn()

    End Sub
End Module

