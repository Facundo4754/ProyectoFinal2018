{ DATABASE bd_rflsystem  delimiter | }

grant dba to "root";
grant dba to "mrosales";
grant dba to "flarrosa";
grant connect to "rfl_administrativo";
grant connect to "rfl_asesores";
grant connect to "rfl_gerentesgenerales";
grant connect to "rfl_administrativos";
grant connect to "rfl_gerentessucursal";











{ TABLE "mrosales".producto row size = 64 number of columns = 4 index size = 9 }

{ unload file name = produ00100.unl number of rows = 0 }

create table "mrosales".producto 
  (
    idproducto integer not null ,
    tipo char(20),
    cepa char(20),
    estadosanitario char(20),
    primary key (idproducto)  constraint "mrosales".pk_producto
  );

revoke all on "mrosales".producto from "public" as "mrosales";

{ TABLE "mrosales".procesos row size = 48 number of columns = 4 index size = 13 }

{ unload file name = proce00101.unl number of rows = 23 }

create table "mrosales".procesos 
  (
    idproceso integer not null ,
    numero integer not null ,
    nombre char(20),
    tipodevino char(20),
    primary key (idproceso,numero)  constraint "mrosales".pk_procesos
  );

revoke all on "mrosales".procesos from "public" as "mrosales";

{ TABLE "mrosales".recipiente row size = 68 number of columns = 5 index size = 9 }

{ unload file name = recip00102.unl number of rows = 0 }

create table "mrosales".recipiente 
  (
    codigo integer not null ,
    unidad char(20),
    nombre char(20),
    capacidad integer,
    material char(20),
    primary key (codigo)  constraint "mrosales".pk_recipiente
  );

revoke all on "mrosales".recipiente from "public" as "mrosales";

{ TABLE "mrosales".cliente row size = 64 number of columns = 4 index size = 9 }

{ unload file name = clien00103.unl number of rows = 0 }

create table "mrosales".cliente 
  (
    cicliente integer not null ,
    nombre char(20),
    apellido char(20),
    direccion char(20),
    primary key (cicliente)  constraint "mrosales".pk_cliente
  );

revoke all on "mrosales".cliente from "public" as "mrosales";

{ TABLE "mrosales".telefonocliente row size = 8 number of columns = 2 index size = 22 }

{ unload file name = telef00104.unl number of rows = 0 }

create table "mrosales".telefonocliente 
  (
    cicliente integer not null ,
    telefono integer not null ,
    primary key (cicliente,telefono)  constraint "mrosales".pk_telefonocliente
  );

revoke all on "mrosales".telefonocliente from "public" as "mrosales";

{ TABLE "mrosales".lugar row size = 24 number of columns = 2 index size = 9 }

{ unload file name = lugar00105.unl number of rows = 0 }

create table "mrosales".lugar 
  (
    idlugar integer not null ,
    propio_ajeno char(20),
    primary key (idlugar)  constraint "mrosales".pk_lugar
  );

revoke all on "mrosales".lugar from "public" as "mrosales";

{ TABLE "mrosales".parcela row size = 8 number of columns = 2 index size = 9 }

{ unload file name = parce00106.unl number of rows = 0 }

create table "mrosales".parcela 
  (
    idlugar integer not null ,
    numparcela integer,
    primary key (idlugar)  constraint "mrosales".pk_parcela
  );

revoke all on "mrosales".parcela from "public" as "mrosales";

{ TABLE "mrosales".bodega row size = 28 number of columns = 3 index size = 9 }

{ unload file name = bodeg00107.unl number of rows = 0 }

create table "mrosales".bodega 
  (
    idlugar integer not null ,
    nombre char(20),
    numsucursal integer,
    primary key (idlugar)  constraint "mrosales".pk_bodega
  );

revoke all on "mrosales".bodega from "public" as "mrosales";

{ TABLE "mrosales".personal row size = 66 number of columns = 5 index size = 9 }

{ unload file name = perso00108.unl number of rows = 4 }

create table "mrosales".personal 
  (
    cipersonal integer not null ,
    nombre char(20),
    apellido char(20),
    direccion char(20),
    eliminado char(2),
    primary key (cipersonal)  constraint "mrosales".pk_persona
  );

revoke all on "mrosales".personal from "public" as "mrosales";

{ TABLE "mrosales".telefonopersonal row size = 8 number of columns = 2 index size = 22 }

{ unload file name = telef00109.unl number of rows = 0 }

create table "mrosales".telefonopersonal 
  (
    cipersonal integer not null ,
    telefono integer not null ,
    primary key (cipersonal,telefono)  constraint "mrosales".pk_telefonopersonal
  );

revoke all on "mrosales".telefonopersonal from "public" as "mrosales";

{ TABLE "mrosales".administrativos row size = 4 number of columns = 1 index size = 9 }

{ unload file name = admin00110.unl number of rows = 0 }

create table "mrosales".administrativos 
  (
    cipersonal integer not null ,
    primary key (cipersonal)  constraint "mrosales".pk_admin
  );

revoke all on "mrosales".administrativos from "public" as "mrosales";

{ TABLE "mrosales".asesores row size = 24 number of columns = 2 index size = 9 }

{ unload file name = aseso00111.unl number of rows = 0 }

create table "mrosales".asesores 
  (
    cipersonal integer not null ,
    tipoasesor char(20),
    primary key (cipersonal)  constraint "mrosales".pk_asesores
  );

revoke all on "mrosales".asesores from "public" as "mrosales";

{ TABLE "mrosales".gerentes row size = 24 number of columns = 2 index size = 9 }

{ unload file name = geren00112.unl number of rows = 0 }

create table "mrosales".gerentes 
  (
    cipersonal integer not null ,
    tipogerente char(20),
    primary key (cipersonal)  constraint "mrosales".pk_gerentes
  );

revoke all on "mrosales".gerentes from "public" as "mrosales";

{ TABLE "mrosales".pasapor row size = 44 number of columns = 7 index size = 43 }

{ unload file name = pasap00113.unl number of rows = 0 }

create table "mrosales".pasapor 
  (
    idproducto integer not null ,
    idproceso integer not null ,
    numero integer not null ,
    fechainicio date not null ,
    fechafinalizacion date,
    unidad char(20),
    cantidad integer,
    primary key (idproducto,idproceso,numero,fechainicio)  constraint "mrosales".pk_pasapor
  );

revoke all on "mrosales".pasapor from "public" as "mrosales";

{ TABLE "mrosales".transporta row size = 40 number of columns = 6 index size = 55 }

{ unload file name = trans00114.unl number of rows = 0 }

create table "mrosales".transporta 
  (
    idproducto integer not null ,
    idlugar integer not null ,
    fecha date not null ,
    matricula char(20) not null ,
    cantidad integer,
    capacidad integer,
    primary key (idproducto,idlugar,fecha,matricula)  constraint "mrosales".pk_transporta
  );

revoke all on "mrosales".transporta from "public" as "mrosales";

{ TABLE "mrosales".interviene row size = 174 number of columns = 7 index size = 43 }

{ unload file name = inter00115.unl number of rows = 0 }

create table "mrosales".interviene 
  (
    cipersonal integer not null ,
    fecha date not null ,
    observaciones char(150),
    idproducto integer,
    idproceso integer,
    numero integer,
    fechainicioproceso date,
    primary key (cipersonal,fecha)  constraint "mrosales".pk_interviene
  );

revoke all on "mrosales".interviene from "public" as "mrosales";

{ TABLE "mrosales".reserva row size = 40 number of columns = 6 index size = 79 }

{ unload file name = reser00116.unl number of rows = 0 }

create table "mrosales".reserva 
  (
    cicliente integer not null ,
    idtipobotella integer not null ,
    tipodevino char(20) not null ,
    fecha_vencimiento date not null ,
    cantidad integer,
    fecha date,
    primary key (cicliente,idtipobotella,tipodevino,fecha_vencimiento,fecha)  constraint 
              "mrosales".pk_reserva
  );

revoke all on "mrosales".reserva from "public" as "mrosales";

{ TABLE "mrosales".embotella row size = 56 number of columns = 10 index size = 115 }

{ unload file name = embot00117.unl number of rows = 0 }

create table "mrosales".embotella 
  (
    idtipobotella integer not null ,
    tipodevino char(20) not null ,
    codigo integer not null ,
    idproducto integer not null ,
    idproceso integer not null ,
    numero integer not null ,
    fechainicioproceso date not null ,
    fechainiciodescarga date not null ,
    fecha date not null ,
    cantidad integer,
    primary key (fecha,idtipobotella,tipodevino,idproducto,idproceso,numero,fechainicioproceso,fechainiciodescarga,codigo) 
               constraint "mrosales".pk_embotella
  );

revoke all on "mrosales".embotella from "public" as "mrosales";

{ TABLE "mrosales".sedescarga row size = 32 number of columns = 8 index size = 59 }

{ unload file name = sedes00118.unl number of rows = 0 }

create table "mrosales".sedescarga 
  (
    codigo integer not null ,
    idproducto integer not null ,
    idproceso integer not null ,
    numero integer not null ,
    fechainicioproceso date not null ,
    cantidad integer,
    fechainicio date not null ,
    fechafinalizacion date,
    primary key (idproducto,idproceso,numero,codigo,fechainicioproceso,fechainicio) 
               constraint "mrosales".pk_sedescarga
  );

revoke all on "mrosales".sedescarga from "public" as "mrosales";

{ TABLE "mrosales".login row size = 40 number of columns = 2 index size = 0 }

{ unload file name = login00119.unl number of rows = 4 }

create table "mrosales".login 
  (
    usuario char(20) not null ,
    cargo char(20) not null 
  );

revoke all on "mrosales".login from "public" as "mrosales";

{ TABLE "mrosales".alertas row size = 128 number of columns = 3 index size = 13 }

{ unload file name = alert00120.unl number of rows = 2 }

create table "mrosales".alertas 
  (
    id integer not null ,
    fecha date not null ,
    alerta char(120),
    primary key (id,fecha)  constraint "mrosales".pk_alertas
  );

revoke all on "mrosales".alertas from "public" as "mrosales";

{ TABLE "mrosales".tipodebotella row size = 31 number of columns = 4 index size = 29 }

{ unload file name = tipod00121.unl number of rows = 6 }

create table "mrosales".tipodebotella 
  (
    idtipobotella integer not null ,
    tipodevino char(20) not null ,
    capacidad decimal(4,2),
    stock integer,
    primary key (idtipobotella,tipodevino)  constraint "mrosales".pk_tipobotella
  );

revoke all on "mrosales".tipodebotella from "public" as "mrosales";




grant select on "mrosales".producto to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".producto to "rfl_administrativos" as "mrosales";
grant select on "mrosales".producto to "rfl_asesores" as "mrosales";
grant select on "mrosales".producto to "rfl_gerentesgeneral" as "mrosales";
grant select on "mrosales".producto to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".procesos to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".procesos to "rfl_administrativos" as "mrosales";
grant select on "mrosales".procesos to "rfl_asesores" as "mrosales";
grant select on "mrosales".procesos to "rfl_gerentesgeneral" as "mrosales";
grant select on "mrosales".procesos to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".recipiente to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".recipiente to "rfl_administrativos" as "mrosales";
grant select on "mrosales".recipiente to "rfl_asesores" as "mrosales";
grant select on "mrosales".recipiente to "rfl_gerentesgeneral" as "mrosales";
grant select on "mrosales".recipiente to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".cliente to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".cliente to "rfl_administrativos" as "mrosales";
grant select on "mrosales".cliente to "rfl_gerentesgeneral" as "mrosales";
grant select on "mrosales".cliente to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".telefonocliente to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".telefonocliente to "rfl_administrativos" as "mrosales";
grant select on "mrosales".telefonocliente to "rfl_gerentesgeneral" as "mrosales";
grant select on "mrosales".telefonocliente to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".lugar to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".lugar to "rfl_administrativos" as "mrosales";
grant select on "mrosales".lugar to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".lugar to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".parcela to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".parcela to "rfl_administrativos" as "mrosales";
grant select on "mrosales".parcela to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".parcela to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".bodega to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".bodega to "rfl_administrativos" as "mrosales";
grant select on "mrosales".bodega to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".bodega to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".personal to "rfl_asesores" as "mrosales";
grant select on "mrosales".personal to "rfl_gerentesgenerales" as "mrosales";
grant update on "mrosales".personal to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".personal to "rfl_gerentessucursal" as "mrosales";
grant update on "mrosales".personal to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".personal to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".telefonopersonal to "rfl_asesores" as "mrosales";
grant select on "mrosales".telefonopersonal to "rfl_gerentesgenerales" as "mrosales";
grant update on "mrosales".telefonopersonal to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".telefonopersonal to "rfl_gerentessucursal" as "mrosales";
grant update on "mrosales".telefonopersonal to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".telefonopersonal to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".administrativos to "rfl_gerentesgenerales" as "mrosales";
grant insert on "mrosales".administrativos to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".asesores to "rfl_gerentesgenerales" as "mrosales";
grant insert on "mrosales".asesores to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".gerentes to "rfl_gerentesgenerales" as "mrosales";
grant insert on "mrosales".gerentes to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".pasapor to "rfl_administrativos" as "mrosales";
grant select on "mrosales".pasapor to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".pasapor to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".interviene to "rfl_asesores" as "mrosales";
grant select on "mrosales".interviene to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".interviene to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".reserva to "rfl_administrativos" as "mrosales";
grant select on "mrosales".reserva to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".reserva to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".embotella to "rfl_administrativos" as "mrosales";
grant select on "mrosales".embotella to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".embotella to "rfl_gerentessucursal" as "mrosales";
grant insert on "mrosales".sedescarga to "rfl_administrativos" as "mrosales";
grant select on "mrosales".sedescarga to "rfl_gerentesgenerales" as "mrosales";
grant select on "mrosales".sedescarga to "rfl_gerentessucursal" as "mrosales";
grant select on "mrosales".login to "public" as "mrosales";
grant update on "mrosales".login to "public" as "mrosales";
grant insert on "mrosales".login to "public" as "mrosales";
grant delete on "mrosales".login to "public" as "mrosales";
grant index on "mrosales".login to "public" as "mrosales";
grant select on "mrosales".alertas to "public" as "mrosales";
grant update on "mrosales".alertas to "public" as "mrosales";
grant insert on "mrosales".alertas to "public" as "mrosales";
grant delete on "mrosales".alertas to "public" as "mrosales";
grant index on "mrosales".alertas to "public" as "mrosales";
grant select on "mrosales".tipodebotella to "rfl_administrativos" as "mrosales";
grant insert on "mrosales".tipodebotella to "rfl_administrativos" as "mrosales";
grant select on "mrosales".tipodebotella to "rfl_gerentesgeneral" as "mrosales";
grant select on "mrosales".tipodebotella to "rfl_gerentessucursal" as "mrosales";
















revoke usage on language SPL from public ;

grant usage on language SPL to public ;








alter table "mrosales".telefonocliente add constraint (foreign 
    key (cicliente) references "mrosales".cliente  on delete cascade 
    constraint "mrosales".fk_telefonocliente);
alter table "mrosales".parcela add constraint (foreign key (idlugar) 
    references "mrosales".lugar  on delete cascade constraint 
    "mrosales".fk_parcela);
alter table "mrosales".bodega add constraint (foreign key (idlugar) 
    references "mrosales".lugar  on delete cascade constraint 
    "mrosales".fk_bodega);
alter table "mrosales".telefonopersonal add constraint (foreign 
    key (cipersonal) references "mrosales".personal  on delete 
    cascade constraint "mrosales".fk_telefonopersonal);
alter table "mrosales".administrativos add constraint (foreign 
    key (cipersonal) references "mrosales".personal  on delete 
    cascade constraint "mrosales".fk_admin);
alter table "mrosales".asesores add constraint (foreign key (cipersonal) 
    references "mrosales".personal  on delete cascade constraint 
    "mrosales".fk_asesores);
alter table "mrosales".gerentes add constraint (foreign key (cipersonal) 
    references "mrosales".personal  on delete cascade constraint 
    "mrosales".fk_gerentes);
alter table "mrosales".pasapor add constraint (foreign key (idproducto) 
    references "mrosales".producto  on delete cascade constraint 
    "mrosales".fk_pasapor);
alter table "mrosales".pasapor add constraint (foreign key (idproceso,
    numero) references "mrosales".procesos  on delete cascade 
    constraint "mrosales".fk_pasapor2);
alter table "mrosales".sedescarga add constraint (foreign key 
    (codigo) references "mrosales".recipiente  on delete cascade 
    constraint "mrosales".fk_sedescarga);
alter table "mrosales".sedescarga add constraint (foreign key 
    (idproducto,idproceso,numero,fechainicioproceso) references 
    "mrosales".pasapor  on delete cascade constraint "mrosales"
    .fk_sedescarga2);
alter table "mrosales".transporta add constraint (foreign key 
    (idproducto) references "mrosales".producto  on delete cascade 
    constraint "mrosales".kfk_transporta);
alter table "mrosales".transporta add constraint (foreign key 
    (idlugar) references "mrosales".lugar  on delete cascade constraint 
    "mrosales".fk_transporta);
alter table "mrosales".interviene add constraint (foreign key 
    (cipersonal) references "mrosales".personal  on delete cascade 
    constraint "mrosales".fk_interviene);
alter table "mrosales".interviene add constraint (foreign key 
    (idproducto,idproceso,numero,fechainicioproceso) references 
    "mrosales".pasapor  on delete cascade constraint "mrosales"
    .fk_interviene2);
alter table "mrosales".embotella add constraint (foreign key 
    (idtipobotella,tipodevino) references "mrosales".tipodebotella 
     on delete cascade constraint "mrosales".fk_embotella);
alter table "mrosales".reserva add constraint (foreign key (cicliente) 
    references "mrosales".cliente  on delete cascade constraint 
    "mrosales".fk_reserva);
alter table "mrosales".reserva add constraint (foreign key (idtipobotella,
    tipodevino) references "mrosales".tipodebotella  on delete 
    cascade constraint "mrosales".fk_reserva2);
alter table "mrosales".embotella add constraint (foreign key 
    (idproducto,idproceso,numero,codigo,fechainicioproceso,fechainiciodescarga) 
    references "mrosales".sedescarga  on delete cascade constraint 
    "mrosales".fk_embotella2);







 



