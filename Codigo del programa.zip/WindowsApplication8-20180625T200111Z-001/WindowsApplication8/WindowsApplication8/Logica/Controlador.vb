﻿Public Class ControladorLogin
    Public Sub Atentificar(ByVal usu As String, ByVal pass As String, ByVal cargo As String)
        Select Case cargo

            'Administrativo
            Case "Administrativo"
                If Conexion.login(usu, cargo) = True Then
                    If pass = "rfladmin" Then
                        Login.Hide()
                        AdminMenu.Show()
                    Else
                        MsgBox("El usuario, contraseña o cargo son incorrectos")
                    End If
                Else
                    MsgBox("El usuario, contraseña o cargo son incorrectos")
                End If

                'Asesor Profesional
            Case "Asesor Profesional"
                Conexion.login(usu, cargo)
                If Conexion.login(usu, cargo) = True Then
                    If pass = "rflasesor" Then
                        Login.Hide()
                        AsesorMenu.Show()
                    Else
                        MsgBox("El usuario, contraseña o cargo son incorrectos")
                    End If
                Else
                    MsgBox("El usuario, contraseña o cargo son incorrectos")
                End If

                'Gerente General
            Case "Gerente General"
                Conexion.login(usu, cargo)
                If Conexion.login(usu, cargo) = True Then
                    If pass = "rflgerenteg" Then
                        Login.Hide()
                        GerenteGMenu.Show()
                    Else
                        MsgBox("El usuario, contraseña o cargo son incorrectos")
                    End If
                Else
                    MsgBox("El usuario, contraseña o cargo son incorrectos")
                End If

                'Gerente de Sucursal
            Case "Gerente de Sucursal"
                Conexion.login(usu, cargo)
                If Conexion.login(usu, cargo) = True Then
                    If pass = "rflgerentesu" Then
                        Login.Hide()
                        GerenteSMenu.Show()
                    Else
                        MsgBox("El usuario, contraseña o cargo son incorrectos")
                    End If
                Else
                    MsgBox("El usuario, contraseña o cargo son incorrectos")
                End If
        End Select
    End Sub
End Class
