﻿Public Class Alertas
    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Hide()
        AsesorMenu.Show()
    End Sub

    Private Sub btnIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresar.Click
        IngresarAlertas(tbID.Text, dtpFin.Text, tbAlerta.Text)
    End Sub
End Class