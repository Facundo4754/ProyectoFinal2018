﻿Public Class CheckEnologo

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If tbContraseña.Text = "rflenologo" Then
            Me.Hide()
            Alertas.Show()
            tbContraseña.Clear()
        Else
            MsgBox("Contraseña incorrecta")
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        AsesorMenu.Show()
    End Sub

End Class