﻿Public Class VerFuncionarios
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteGMenu.Show()
    End Sub

    Private Sub VerFuncionarios_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConsultaPersonal()
        ConsultaTelefonoPersonal()
    End Sub
End Class