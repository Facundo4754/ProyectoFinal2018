﻿Public Class BajaGerentes
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteGMenu.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If ConsultaBaja2(tbCedula.Text) = True Then
            MsgBox("Persona Encontrada")
            btnBaja.Enabled = True
        Else
            MsgBox("Persona No encontrada")
        End If
    End Sub

    Private Sub btnBaja_Click(sender As Object, e As EventArgs) Handles btnBaja.Click
        BajaPersonal(tbCedula.Text)
        btnBaja.Enabled = False
        tbCedula.Clear()
    End Sub
End Class