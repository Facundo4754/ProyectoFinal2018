﻿Public Class Login
    'Boton Ingresar
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresar.Click
        Dim usu As String
        Dim pass As String
        Dim cargo As String
        Dim validar As New ControladorLogin
        usu = tbUsuario.Text
        pass = tbContraseña.Text
        cargo = cmbCargo.SelectedItem
        validar.Atentificar(usu, pass, cargo)
    End Sub
    'Boton Salir
    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
