﻿Public Class Bodegas
    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        Lugar(tbLugar.Text, cmbOrigen.Text)
        Parcela(tbLugar.Text, tbNumParcela.Text)
        Bodega(tbLugar.Text, tbNomBodega.Text, tbNumSucursal.Text)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs)
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub tbLugar_MouseMove(sender As Object, e As MouseEventArgs) Handles tbLugar.MouseMove, tbNomBodega.MouseMove, tbNumSucursal.MouseMove, tbNumParcela.MouseMove
        If String.IsNullOrEmpty(tbNumParcela.Text) Or
        String.IsNullOrEmpty(tbLugar.Text) Or
        String.IsNullOrEmpty(tbNomBodega.Text) Or
        String.IsNullOrEmpty(tbNumSucursal.Text) Then
            btnIngresar.Enabled = False
        Else
            btnIngresar.Enabled = True
        End If
    End Sub
End Class