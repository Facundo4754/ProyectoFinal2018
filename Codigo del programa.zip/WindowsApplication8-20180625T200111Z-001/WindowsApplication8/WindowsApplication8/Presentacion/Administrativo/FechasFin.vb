﻿Public Class FechasFin

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        FechaFinalProceso(dtpFin.Text, tbProducto.Text, tbProceso.Text, tbNumero.Text)
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        FechaFinalDescarga(dtpFin2.Text, tbCodigo.Text)
    End Sub

    Private Sub tbProducto_MouseMove(sender As Object, e As MouseEventArgs) Handles tbProducto.MouseMove, tbProceso.MouseMove, tbNumero.MouseMove
        If String.IsNullOrEmpty(tbProducto.Text) Or
        String.IsNullOrEmpty(tbProceso.Text) Or
        String.IsNullOrEmpty(tbNumero.Text) Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub

    Private Sub tbCodigo_MouseMove(sender As Object, e As MouseEventArgs) Handles tbCodigo.MouseMove
        If String.IsNullOrEmpty(tbCodigo.Text) Then
            Button2.Enabled = False
        Else
            Button2.Enabled = True
        End If
    End Sub
End Class