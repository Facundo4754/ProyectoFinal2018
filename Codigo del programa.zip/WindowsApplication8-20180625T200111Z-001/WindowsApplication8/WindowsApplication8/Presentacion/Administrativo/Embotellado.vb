﻿Public Class Embotellado
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub btnIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresar.Click
        Embotella(cmbID.Text, cmbTipo2.Text, tbCodigo.Text, tbProducto.Text, tbProceso.Text, tbNumProceso.Text, dtpInicioProceso.Text, dtpInicioDescarga.Text, dtpFecha.Text, tbCantidad.Text)
        SumarStock(tbCantidad.Text, cmbID.Text)
    End Sub

    Private Sub Embotellado_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Combo5()
        ConsultaSeDescarga()
        ConsultaBotellas()
    End Sub

    Private Sub cmbID_MouseMove(sender As Object, e As MouseEventArgs) Handles tbProducto.MouseMove, tbProceso.MouseMove, tbNumProceso.MouseMove, tbCodigo.MouseMove, tbCantidad.MouseMove, cmbTipo2.MouseMove, cmbID.MouseMove
        If String.IsNullOrEmpty(cmbID.Text) Or
        String.IsNullOrEmpty(cmbTipo2.Text) Or
        String.IsNullOrEmpty(tbCantidad.Text) Or
        String.IsNullOrEmpty(tbCodigo.Text) Or
        String.IsNullOrEmpty(tbProducto.Text) Or
        String.IsNullOrEmpty(tbProceso.Text) Or
        String.IsNullOrEmpty(tbNumProceso.Text) Then
            btnIngresar.Enabled = False
        Else
            btnIngresar.Enabled = True
        End If
    End Sub

End Class