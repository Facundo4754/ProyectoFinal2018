﻿Public Class DatosReserva
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        AdminMenu.Show()
    End Sub

    Private Sub btnReservar_Click(sender As Object, e As EventArgs) Handles btnReservar.Click
        Cliente(tbCedula.Text, tbNombre.Text, tbApellido.Text, tbDireccion.Text)
        TelefonoCliente(tbCedula.Text, tbTelefono1.Text)
        TelefonoCliente2(tbCedula.Text, tbTelefono2.Text)

    End Sub

    Private Sub DatosReserva_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Combo1()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Reserva(tbCedula2.Text, cmbIdBotella.Text, cmbTipo.Text, dtpVencimiento.Text, tbCantidad.Text, dtpFecha.Text)
        RestarStock(tbCantidad.Text, cmbIdBotella.Text)
    End Sub

    Private Sub tbCedula_MouseMove(sender As Object, e As MouseEventArgs) Handles tbTelefono2.MouseMove, tbTelefono1.MouseMove, tbNombre.MouseMove, tbDireccion.MouseMove, tbCedula.MouseMove, tbApellido.MouseMove
        If String.IsNullOrEmpty(tbCedula.Text) Or
        String.IsNullOrEmpty(tbNombre.Text) Or
        String.IsNullOrEmpty(tbApellido.Text) Or
        String.IsNullOrEmpty(tbTelefono1.Text) Or
        String.IsNullOrEmpty(tbTelefono2.Text) Or
        String.IsNullOrEmpty(tbDireccion.Text) Then
            btnReservar.Enabled = False
        Else
            btnReservar.Enabled = True
        End If
    End Sub

    Private Sub tbCedula2_MouseMove(sender As Object, e As MouseEventArgs) Handles tbCedula2.MouseMove, tbCantidad.MouseMove, cmbTipo.MouseMove, cmbIdBotella.MouseMove
        If String.IsNullOrEmpty(tbCedula2.Text) Or
        String.IsNullOrEmpty(cmbIdBotella.Text) Or
        String.IsNullOrEmpty(cmbTipo.Text) Or
        String.IsNullOrEmpty(tbCantidad.Text) Then
            btnReservar.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub
End Class