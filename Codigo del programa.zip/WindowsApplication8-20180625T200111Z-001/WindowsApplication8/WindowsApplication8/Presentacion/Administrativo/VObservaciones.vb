﻿Public Class VObservaciones
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
    End Sub

    Private Sub VObservaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConsultarObservaciones()
    End Sub
End Class