﻿Public Class BajaFuncionarios
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        GerenteSMenu.Show()
    End Sub

    Private Sub btnBaja_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBaja.Click
        BajaPersonal(tbCedula.Text)
        btnBaja.Enabled = False
        tbCedula.Clear()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If ConsultaBaja(tbCedula.Text) = True Then
            MsgBox("Persona Encontrada")
            btnBaja.Enabled = True
        Else
            MsgBox("Persona No encontrada")
        End If
    End Sub
End Class