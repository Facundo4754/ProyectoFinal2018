﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Estadisticas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title1 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Title2 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title()
        Me.ChartTipoProducto = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.ChartCepas = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        CType(Me.ChartTipoProducto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ChartCepas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'ChartTipoProducto
        '
        Me.ChartTipoProducto.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ChartTipoProducto.BorderlineColor = System.Drawing.Color.Transparent
        ChartArea1.AxisX.LabelStyle.ForeColor = System.Drawing.Color.White
        ChartArea1.AxisX.LineColor = System.Drawing.Color.White
        ChartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.Transparent
        ChartArea1.AxisX.MajorTickMark.LineColor = System.Drawing.Color.White
        ChartArea1.AxisX.TitleForeColor = System.Drawing.Color.White
        ChartArea1.AxisY.LabelStyle.ForeColor = System.Drawing.Color.White
        ChartArea1.AxisY.LineColor = System.Drawing.Color.White
        ChartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.Transparent
        ChartArea1.AxisY.MajorTickMark.LineColor = System.Drawing.Color.White
        ChartArea1.AxisY.TitleForeColor = System.Drawing.Color.White
        ChartArea1.BackColor = System.Drawing.Color.Transparent
        ChartArea1.Name = "ChartArea1"
        Me.ChartTipoProducto.ChartAreas.Add(ChartArea1)
        Legend1.BackColor = System.Drawing.Color.Transparent
        Legend1.ForeColor = System.Drawing.Color.White
        Legend1.Name = "Legend1"
        Me.ChartTipoProducto.Legends.Add(Legend1)
        Me.ChartTipoProducto.Location = New System.Drawing.Point(403, 37)
        Me.ChartTipoProducto.Name = "ChartTipoProducto"
        Me.ChartTipoProducto.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.ChartTipoProducto.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.MediumOrchid, System.Drawing.Color.DarkViolet, System.Drawing.Color.Indigo, System.Drawing.Color.MediumPurple, System.Drawing.Color.DarkSlateBlue, System.Drawing.Color.SlateBlue}
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar
        Series1.LabelForeColor = System.Drawing.Color.White
        Series1.Legend = "Legend1"
        Series1.Name = "Producto"
        Me.ChartTipoProducto.Series.Add(Series1)
        Me.ChartTipoProducto.Size = New System.Drawing.Size(388, 222)
        Me.ChartTipoProducto.TabIndex = 1
        Title1.BackColor = System.Drawing.Color.Transparent
        Title1.ForeColor = System.Drawing.Color.White
        Title1.Name = "Cantidad de producto por tipo"
        Title1.Text = "Cantidad de producto por tipo"
        Me.ChartTipoProducto.Titles.Add(Title1)
        '
        'ChartCepas
        '
        Me.ChartCepas.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.ChartCepas.BorderlineColor = System.Drawing.Color.Transparent
        ChartArea2.AxisX.LabelStyle.ForeColor = System.Drawing.Color.White
        ChartArea2.AxisX.LineColor = System.Drawing.Color.White
        ChartArea2.AxisX.MajorGrid.LineColor = System.Drawing.Color.Transparent
        ChartArea2.AxisX.MajorTickMark.LineColor = System.Drawing.Color.White
        ChartArea2.AxisX.TitleForeColor = System.Drawing.Color.White
        ChartArea2.AxisY.LabelStyle.ForeColor = System.Drawing.Color.White
        ChartArea2.AxisY.LineColor = System.Drawing.Color.White
        ChartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.Transparent
        ChartArea2.AxisY.MajorTickMark.LineColor = System.Drawing.Color.White
        ChartArea2.AxisY.TitleForeColor = System.Drawing.Color.White
        ChartArea2.BackColor = System.Drawing.Color.Transparent
        ChartArea2.Name = "ChartArea1"
        Me.ChartCepas.ChartAreas.Add(ChartArea2)
        Legend2.BackColor = System.Drawing.Color.Transparent
        Legend2.ForeColor = System.Drawing.Color.White
        Legend2.Name = "Legend1"
        Me.ChartCepas.Legends.Add(Legend2)
        Me.ChartCepas.Location = New System.Drawing.Point(2, 37)
        Me.ChartCepas.Name = "ChartCepas"
        Me.ChartCepas.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.ChartCepas.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.MediumOrchid, System.Drawing.Color.DarkViolet, System.Drawing.Color.Indigo, System.Drawing.Color.MediumPurple, System.Drawing.Color.DarkSlateBlue, System.Drawing.Color.SlateBlue}
        Series2.ChartArea = "ChartArea1"
        Series2.Legend = "Legend1"
        Series2.Name = "Cepas"
        Series2.YValuesPerPoint = 4
        Me.ChartCepas.Series.Add(Series2)
        Me.ChartCepas.Size = New System.Drawing.Size(395, 222)
        Me.ChartCepas.TabIndex = 2
        Title2.ForeColor = System.Drawing.Color.White
        Title2.Name = "Title1"
        Title2.Text = "Cantidad de producto por cepa"
        Me.ChartCepas.Titles.Add(Title2)
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Indigo
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(800, 31)
        Me.Panel2.TabIndex = 37
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(320, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(206, 19)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "ESTADISTICAS Y GRAFICAS"
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkViolet
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Century Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button9.Image = Global.WindowsApplication8.My.Resources.Resources.back
        Me.Button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button9.Location = New System.Drawing.Point(12, 276)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(85, 36)
        Me.Button9.TabIndex = 125
        Me.Button9.Text = "Atrás"
        Me.Button9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Estadisticas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(26, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 334)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.ChartCepas)
        Me.Controls.Add(Me.ChartTipoProducto)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Estadisticas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.ChartTipoProducto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ChartCepas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ChartTipoProducto As DataVisualization.Charting.Chart
    Friend WithEvents ChartCepas As DataVisualization.Charting.Chart
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Button9 As System.Windows.Forms.Button
End Class
