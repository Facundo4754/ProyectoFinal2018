﻿Public Class Estadisticas
    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Me.Close()
        GerenteSMenu.Show()
    End Sub

    Private Sub Estadisticas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim datos As New ArrayList
        datos = GraficoTipoProducto()
        Dim index As Integer
        For index = 0 To datos.Count - 1
            ChartTipoProducto.Series("Producto").Points.AddXY(datos(index)(0), datos(index)(1))
        Next

        Dim datos2 As New ArrayList
        datos2 = GraficoCepas()
        For index = 0 To datos2.Count - 1
            ChartCepas.Series("Cepas").Points.AddXY(datos2(index)(0), datos2(index)(1))
        Next

    End Sub
End Class